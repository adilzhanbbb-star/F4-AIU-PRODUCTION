/* DummyJSON сұраулары және браузерде сақталатын тапсырмалар. */
(function () {
  "use strict";

  const API_URL = "https://dummyjson.com";
  const STORAGE_KEY = "tizim.todos.v1";
  const MAX_TEXT_LENGTH = 500;
  let localSequence = 0;

  function isPositiveInteger(value) {
    return Number.isSafeInteger(value) && value > 0;
  }

  function validateText(value) {
    if (typeof value !== "string" || !value.trim()) {
      throw new Error("Тапсырма мәтінін жазыңыз.");
    }
    const text = value.trim();
    if (text.length > MAX_TEXT_LENGTH) {
      throw new Error("Тапсырма 500 таңбадан аспауы керек.");
    }
    return text;
  }

  function validateTask(task) {
    return task !== null && typeof task === "object" &&
      typeof task.id === "string" && task.id.length > 0 && task.id.length <= 200 &&
      (task.apiId === null || isPositiveInteger(task.apiId)) &&
      typeof task.todo === "string" && task.todo.trim().length > 0 &&
      task.todo.length <= MAX_TEXT_LENGTH &&
      typeof task.completed === "boolean" && isPositiveInteger(task.userId);
  }

  function copyTask(task) {
    return {
      id: task.id,
      apiId: task.apiId,
      todo: task.todo,
      completed: task.completed,
      userId: task.userId,
    };
  }

  class TodoStore {
    constructor() {
      this.todos = [];
      this.source = null;
      this.storageAvailable = false;
      this._storage = null;

      try {
        this._storage = window.localStorage;
        const probe = STORAGE_KEY + ".probe";
        this._storage.setItem(probe, "1");
        this._storage.removeItem(probe);
        this.storageAvailable = true;
      } catch (_) {
        // Сақтау өшірілсе де, ағымдағы бетте жұмыс жалғасады.
      }
    }

    async load() {
      const cached = this._readCache();
      if (cached !== null) {
        this.todos = cached;
        this.source = "cache";
        return this.todos;
      }

      // GET: API-ден тапсырмалардың толық тізімін алу.
      const data = await this._request("GET", "/todos?limit=0");
      if (!data || !Array.isArray(data.todos)) {
        throw new Error("Сервер тапсырмалар тізімін дұрыс жібермеді.");
      }

      const ids = new Set();
      const tasks = data.todos.map(function (task) {
        if (!task || !isPositiveInteger(task.id)) {
          throw new Error("Сервер тапсырмалар тізімін дұрыс жібермеді.");
        }
        const result = {
          id: "api:" + task.id,
          apiId: task.id,
          todo: task.todo,
          completed: task.completed,
          userId: task.userId,
        };
        if (!validateTask(result) || ids.has(result.id)) {
          throw new Error("Сервер тапсырмалар тізімін дұрыс жібермеді.");
        }
        ids.add(result.id);
        return result;
      });

      this.todos = tasks;
      this.source = "api";
      this._save();
      return this.todos;
    }

    async add(text) {
      const todo = validateText(text);
      // POST: DummyJSON қосуды тек имитациялайды; нәтиже өз браузерімізде сақталады.
      await this._request("POST", "/todos/add", {
        todo: todo,
        completed: false,
        userId: 1,
      });

      const task = {
        id: this._newLocalId(),
        // Қосылған тапсырма серверде жоқ, сондықтан оған PATCH/DELETE жіберілмейді.
        apiId: null,
        todo: todo,
        completed: false,
        userId: 1,
      };
      this.todos = [task].concat(this.todos);
      this._save();
      return task;
    }

    async update(id, patch) {
      const existing = this._find(id);
      if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
        throw new Error("Өзгерістер дұрыс берілмеді.");
      }
      const keys = Object.keys(patch);
      if (!keys.length || keys.some(function (key) {
        return key !== "todo" && key !== "completed";
      })) {
        throw new Error("Өзгерістер дұрыс берілмеді.");
      }

      const changes = {};
      if (Object.prototype.hasOwnProperty.call(patch, "todo")) {
        changes.todo = validateText(patch.todo);
      }
      if (Object.prototype.hasOwnProperty.call(patch, "completed")) {
        if (typeof patch.completed !== "boolean") {
          throw new Error("Тапсырманың күйі дұрыс берілмеді.");
        }
        changes.completed = patch.completed;
      }

      // PATCH: бастапқы API тапсырмасының мәтінін не орындалу күйін өзгерту.
      if (existing.apiId !== null) {
        await this._request("PATCH", "/todos/" + existing.apiId, changes);
      }

      // Сервер жауабы бұрынғы жергілікті өзгерістерді қайта жазбауы керек.
      const updated = Object.assign({}, this._find(id), changes);
      this.todos = this.todos.map(function (task) {
        return task.id === id ? updated : task;
      });
      this._save();
      return updated;
    }

    async remove(id) {
      const existing = this._find(id);
      // DELETE: бастапқы API тапсырмасын өшіру сұрауы.
      if (existing.apiId !== null) {
        await this._request("DELETE", "/todos/" + existing.apiId);
      }
      const removed = this.todos.find(function (task) { return task.id === id; }) || existing;
      this.todos = this.todos.filter(function (task) { return task.id !== id; });
      this._save();
      return removed;
    }

    _find(id) {
      const task = this.todos.find(function (item) { return item.id === id; });
      if (!task) throw new Error("Тапсырма табылмады.");
      return task;
    }

    _newLocalId() {
      let id;
      do {
        localSequence += 1;
        id = "local:" + Date.now().toString(36) + ":" +
          localSequence.toString(36) + ":" + Math.random().toString(36).slice(2, 10);
      } while (this.todos.some(function (task) { return task.id === id; }));
      return id;
    }

    _readCache() {
      if (!this._storage) return null;
      let raw;
      try {
        raw = this._storage.getItem(STORAGE_KEY);
      } catch (_) {
        this.storageAvailable = false;
        return null;
      }
      if (raw === null) return null;

      try {
        const data = JSON.parse(raw);
        if (!data || data.version !== 1 || !Array.isArray(data.todos)) {
          throw new Error("Invalid cache");
        }
        const ids = new Set();
        const apiIds = new Set();
        for (const task of data.todos) {
          if (!validateTask(task) || ids.has(task.id) ||
              (task.apiId !== null && apiIds.has(task.apiId))) {
            throw new Error("Invalid cache");
          }
          ids.add(task.id);
          if (task.apiId !== null) apiIds.add(task.apiId);
        }
        // Бос массив те жарамды: пайдаланушы барлық тапсырманы өшірген болуы мүмкін.
        return data.todos.map(copyTask);
      } catch (_) {
        try {
          this._storage.removeItem(STORAGE_KEY);
        } catch (_) {
          this.storageAvailable = false;
        }
        return null;
      }
    }

    _save() {
      if (!this._storage) return;
      try {
        this._storage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, todos: this.todos }));
        this.storageAvailable = true;
      } catch (_) {
        this.storageAvailable = false;
      }
    }

    async _request(method, path, body) {
      const controller = new AbortController();
      const timer = setTimeout(function () { controller.abort(); }, 12000);
      try {
        const options = { method: method, signal: controller.signal };
        if (body !== undefined) {
          options.headers = { "Content-Type": "application/json" };
          options.body = JSON.stringify(body);
        }
        const response = await fetch(API_URL + path, options);
        if (!response.ok) {
          throw new Error(response.status === 404
            ? "Тапсырма серверде табылмады."
            : "Сервер сұрауды орындай алмады. Қайта көріңіз.");
        }
        return await response.json();
      } catch (error) {
        if (error.name === "AbortError") {
          throw new Error("Серверден жауап кешікті. Қайта көріңіз.");
        }
        if (error instanceof TypeError) {
          throw new Error("Серверге қосылу мүмкін болмады. Интернет байланысын тексеріңіз.");
        }
        if (error instanceof SyntaxError) {
          throw new Error("Серверден қате жауап келді. Қайта көріңіз.");
        }
        throw error;
      } finally {
        clearTimeout(timer);
      }
    }
  }

  TodoStore.STORAGE_KEY = STORAGE_KEY;
  window.TodoStore = TodoStore;
})();
