/* Interface logic. API calls and browser storage live in store.js. */
(() => {
  'use strict';

  const store = new window.TodoStore();
  const $ = (id) => document.getElementById(id);
  const pageSize = 6;
  const state = { ready: false, loading: false, error: '', filter: 'all', search: '', page: 1, editing: null, busy: new Set(), adding: false };
  let toastTimeout;

  function icon(name) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'icon');
    svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#icon-' + name);
    svg.append(use);
    return svg;
  }

  function button(name, label, className, action) {
    const element = document.createElement('button');
    element.type = 'button';
    element.className = 'icon-button ' + className;
    element.setAttribute('aria-label', label);
    element.title = label;
    if (action) element.dataset.action = action;
    element.append(icon(name));
    return element;
  }

  function toast(message, isError = false) {
    clearTimeout(toastTimeout);
    $('toast').textContent = message;
    $('toast').classList.toggle('is-error', isError);
    $('toast').hidden = false;
    toastTimeout = setTimeout(() => { $('toast').hidden = true; }, isError ? 6500 : 2800);
  }

  function filteredTodos() {
    const query = state.search.trim().toLocaleLowerCase('kk');
    return store.todos.filter((todo) => {
      const matchesFilter = state.filter === 'all' || (state.filter === 'completed' ? todo.completed : !todo.completed);
      return matchesFilter && (!query || todo.todo.toLocaleLowerCase('kk').includes(query));
    });
  }

  function renderStorage() {
    $('save-status').classList.toggle('is-error', !store.storageAvailable || Boolean(state.error));
    $('save-label').textContent = state.adding || state.busy.size ? 'Сақталуда…' : (!state.ready ? (state.error ? 'Байланыс жоқ' : 'Қосылуда') : (store.storageAvailable ? 'Осы браузерде сақталады' : 'Уақытша сақталды'));
    $('save-status').title = 'Өзгерістер тек осы браузерде сақталады.';
    $('storage-notice').hidden = !state.ready || store.storageAvailable;
    $('storage-notice').textContent = 'Браузерде сақтау қолжетімсіз. Бетті жаңартсаңыз, өзгерістер жоғалуы мүмкін.';
  }

  function renderStats() {
    const total = store.todos.length;
    const completed = store.todos.filter((todo) => todo.completed).length;
    const percent = total ? Math.round(completed / total * 100) : 0;
    $('total-count').textContent = state.ready ? total : '—';
    $('active-count').textContent = state.ready ? total - completed : '—';
    $('done-count').textContent = state.ready ? completed : '—';
    $('all-badge').textContent = total;
    $('progress-percent').textContent = percent + '%';
    $('mini-progress').style.setProperty('--progress', percent + '%');
    $('mini-progress').setAttribute('aria-valuenow', percent);
    renderStorage();
  }

  function makeRow(todo) {
    const row = document.createElement('li');
    row.className = 'todo-row';
    row.classList.toggle('completed', todo.completed);
    row.classList.toggle('is-busy', state.busy.has(todo.id));
    row.dataset.id = todo.id;
    const check = button('check', todo.completed ? 'Қайта белсенді ету' : 'Орындалды деп белгілеу', 'completion-button', 'toggle');
    check.setAttribute('aria-pressed', String(todo.completed));
    check.disabled = state.adding || state.busy.size > 0 || Boolean(state.editing);
    row.append(check);

    if (state.editing?.id === todo.id) {
      const form = document.createElement('form');
      form.className = 'edit-form';
      form.noValidate = true;
      form.classList.toggle('has-error', Boolean(state.editing.error));
      const input = document.createElement('input');
      input.className = 'edit-input';
      input.value = state.editing.text;
      input.maxLength = 500;
      input.required = true;
      input.setAttribute('aria-label', 'Тапсырманы өңдеу');
      input.setAttribute('aria-invalid', String(Boolean(state.editing.error)));
      input.disabled = state.busy.has(todo.id);
      const controls = document.createElement('div');
      controls.className = 'edit-controls';
      const save = button('check', 'Өзгерісті сақтау', 'save-button');
      save.type = 'submit';
      save.disabled = state.busy.has(todo.id);
      const cancel = button('close', 'Өңдеуден бас тарту', 'cancel-button', 'cancel');
      cancel.disabled = state.busy.has(todo.id);
      controls.append(save, cancel);
      form.append(input, controls);
      row.append(form);
    } else {
      const text = document.createElement('p');
      text.className = 'todo-text';
      // textContent keeps API and user text as plain text, including HTML-like input.
      text.textContent = todo.todo;
      const actions = document.createElement('div');
      actions.className = 'todo-actions';
      const edit = button('pencil', 'Тапсырманы өңдеу', 'edit-button', 'edit');
      const remove = button('trash', 'Тапсырманы өшіру', 'delete-button', 'delete');
      edit.disabled = remove.disabled = state.adding || state.busy.size > 0 || Boolean(state.editing);
      actions.append(edit, remove);
      row.append(text, actions);
    }
    return row;
  }

  function renderMessage(kind, title, description) {
    const box = $('list-state');
    box.className = 'list-state' + (kind === 'error' ? ' state-error' : '');
    box.replaceChildren();
    box.hidden = false;
    const emblem = document.createElement('span');
    emblem.className = kind === 'loading' ? 'loader' : 'state-icon';
    if (kind !== 'loading') emblem.append(icon(kind === 'error' ? 'refresh' : (state.search ? 'search' : 'check')));
    box.append(emblem);
    if (title) {
      const heading = document.createElement('h2');
      heading.textContent = title;
      box.append(heading);
    }
    const body = document.createElement('p');
    body.textContent = description;
    box.append(body);
    if (kind === 'error') {
      const retry = button('refresh', 'Қайта жүктеу', 'retry-button');
      retry.addEventListener('click', loadTodos);
      box.append(retry);
    }
  }

  function render() {
    renderStats();
    // Finish saving/cancelling the current edit before changing the list.
    // This also keeps a slow API response from discarding a new draft.
    const locked = state.adding || state.busy.size > 0 || Boolean(state.editing);
    $('add-button').disabled = !state.ready || locked;
    $('new-task').disabled = !state.ready || locked;
    $('search').disabled = !state.ready || locked;
    $('add-form').setAttribute('aria-busy', String(state.adding));
    document.querySelectorAll('[data-filter]').forEach((element) => {
      const selected = element.dataset.filter === state.filter;
      element.setAttribute('aria-pressed', String(selected));
      element.classList.toggle('is-selected', selected);
      element.disabled = !state.ready || locked;
    });
    const todos = filteredTodos();
    const pages = Math.max(1, Math.ceil(todos.length / pageSize));
    state.page = Math.max(1, Math.min(state.page, pages));
    const start = (state.page - 1) * pageSize;
    const visible = todos.slice(start, start + pageSize);
    $('todo-list').replaceChildren(...visible.map(makeRow));
    $('todo-list').setAttribute('aria-busy', String(state.loading));
    $('list-state').hidden = true;
    $('pagination').hidden = !state.ready || todos.length <= pageSize;
    $('previous-page').disabled = state.page === 1 || locked;
    $('next-page').disabled = state.page === pages || locked;
    $('page-indicator').textContent = state.page + ' / ' + pages;
    $('list-caption').textContent = state.ready ? (todos.length ? `${todos.length} тапсырманың ${start + 1}–${start + visible.length} көрсетілді` : '0 тапсырма') : (state.error ? 'Қайта жүктеп көріңіз' : 'Тізім дайындалуда');
    if (state.loading) renderMessage('loading', '', 'Тапсырмалар жүктелуде…');
    else if (state.error) renderMessage('error', 'Тізімді жүктеу мүмкін болмады', state.error);
    else if (!todos.length) {
      const title = state.search ? 'Тапсырма табылмады' : (state.filter === 'completed' ? 'Әзірге орындалған тапсырма жоқ' : (state.filter === 'active' && store.todos.length ? 'Барлық тапсырма орындалды!' : 'Тізіміңіз бос'));
      const description = state.search ? 'Басқа сөзбен іздеп көріңіз.' : (state.filter === 'completed' ? 'Орындалған істі құсбелгімен белгілеңіз.' : 'Жаңа тапсырманы жоғарыдағы жолға жазыңыз.');
      renderMessage('empty', title, description);
    }
  }

  function focusEdit(select = false) {
    const input = $('todo-list').querySelector('.edit-input');
    if (input) { input.focus(); if (select) input.select(); }
  }

  function focusRow(id, action = 'edit') {
    const row = Array.from($('todo-list').children).find((element) => element.dataset.id === id);
    const target = row?.querySelector(`[data-action="${action}"]`);
    if (target) target.focus();
    else $('new-task').focus();
  }

  async function loadTodos() {
    if (state.loading) return;
    state.loading = true;
    state.error = '';
    render();
    try {
      await store.load();
      state.ready = true;
    } catch (error) {
      state.error = error.message || 'Интернет байланысын тексеріп, қайталап көріңіз.';
    } finally {
      state.loading = false;
      render();
    }
  }

  async function mutate(id, operation, successMessage) {
    if (state.busy.has(id)) return false;
    state.busy.add(id);
    render();
    let success = false;
    try {
      await operation();
      success = true;
      toast(successMessage);
    } catch (error) {
      toast(error.message || 'Өзгерісті сақтау мүмкін болмады. Қайталап көріңіз.', true);
    } finally {
      state.busy.delete(id);
    }
    return success;
  }

  $('add-form').noValidate = true;
  $('add-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!state.ready || state.adding || state.busy.size || state.editing) return;
    const text = $('new-task').value.trim();
    if (!text || text.length > 500) {
      $('add-error').textContent = 'Тапсырма мәтінін жазыңыз (1–500 таңба).';
      $('add-error').hidden = false;
      $('new-task').setAttribute('aria-invalid', 'true');
      $('new-task').setAttribute('aria-describedby', 'add-error');
      $('new-task').focus();
      return;
    }
    state.adding = true;
    $('add-error').hidden = true;
    render();
    try {
      await store.add(text);
      $('new-task').value = '';
      state.filter = 'all';
      state.search = '';
      state.page = 1;
      state.editing = null;
      $('search').value = '';
      toast('Жаңа тапсырма қосылды');
    } catch (error) {
      $('add-error').textContent = error.message || 'Тапсырма қосылмады. Қайталап көріңіз.';
      $('add-error').hidden = false;
    } finally {
      state.adding = false;
      render();
      $('new-task').focus();
    }
  });

  $('new-task').addEventListener('input', () => {
    $('add-error').hidden = true;
    $('new-task').removeAttribute('aria-invalid');
    $('new-task').removeAttribute('aria-describedby');
  });

  $('todo-list').addEventListener('click', async (event) => {
    const target = event.target.closest('button[data-action]');
    if (!target) return;
    const id = target.closest('.todo-row').dataset.id;
    const todo = store.todos.find((item) => item.id === id);
    if (!todo || state.adding || state.busy.size) return;
    const action = target.dataset.action;
    if (action === 'edit') {
      state.editing = { id, text: todo.todo, error: false };
      render();
      focusEdit(true);
    } else if (action === 'cancel') {
      state.editing = null;
      render();
      focusRow(id);
    } else if (action === 'toggle') {
      const completed = !todo.completed;
      await mutate(id, () => store.update(id, { completed }), completed ? 'Тапсырма орындалды. Жарайсыз!' : 'Тапсырма қайта белсенді етілді');
      render();
      focusRow(id, 'toggle');
    } else if (action === 'delete') {
      await mutate(id, () => store.remove(id), 'Тапсырма өшірілді');
      render();
      focusRow(id, 'delete');
    }
  });

  $('todo-list').addEventListener('input', (event) => {
    if (event.target.matches('.edit-input') && state.editing) {
      state.editing.text = event.target.value;
      state.editing.error = false;
      event.target.setAttribute('aria-invalid', 'false');
      event.target.closest('.edit-form').classList.remove('has-error');
    }
  });

  $('todo-list').addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && state.editing && !state.busy.has(state.editing.id)) {
      const id = state.editing.id;
      state.editing = null;
      render();
      focusRow(id);
    }
  });

  $('todo-list').addEventListener('submit', async (event) => {
    if (!event.target.matches('.edit-form')) return;
    event.preventDefault();
    if (!state.editing || state.busy.has(state.editing.id)) return;
    const { id } = state.editing;
    const text = state.editing.text.trim();
    if (!text || text.length > 500) {
      state.editing.error = true;
      toast('Тапсырма мәтінін жазыңыз (1–500 таңба).', true);
      render();
      focusEdit();
      return;
    }
    const success = await mutate(id, () => store.update(id, { todo: text }), 'Өзгеріс сақталды');
    if (success && state.editing?.id === id) state.editing = null;
    render();
    if (state.editing) focusEdit();
    else focusRow(id);
  });

  document.querySelectorAll('[data-filter]').forEach((element) => {
    element.addEventListener('click', () => {
      state.filter = element.dataset.filter;
      state.page = 1;
      state.editing = null;
      render();
    });
  });

  $('search').addEventListener('input', (event) => {
    state.search = event.target.value;
    state.page = 1;
    state.editing = null;
    render();
  });

  function changePage(delta) {
    state.page += delta;
    state.editing = null;
    render();
  }
  $('previous-page').addEventListener('click', () => changePage(-1));
  $('next-page').addEventListener('click', () => changePage(1));

  // Explicit names also work in browsers without Kazakh Intl locale data.
  const dateParts = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Almaty', year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(new Date());
  const part = (type) => dateParts.find((item) => item.type === type).value;
  const dateISO = [part('year'), part('month').padStart(2, '0'), part('day').padStart(2, '0')].join('-');
  const months = ['қаңтар', 'ақпан', 'наурыз', 'сәуір', 'мамыр', 'маусым', 'шілде', 'тамыз', 'қыркүйек', 'қазан', 'қараша', 'желтоқсан'];
  const weekdays = ['жексенбі', 'дүйсенбі', 'сейсенбі', 'сәрсенбі', 'бейсенбі', 'жұма', 'сенбі'];
  $('today').dateTime = dateISO;
  $('today').textContent = `${part('day')} ${months[Number(part('month')) - 1]}, ${weekdays[new Date(dateISO + 'T12:00:00Z').getUTCDay()]}`;
  loadTodos();
})();
